package yatzy.refactoring;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class Yatzy {

	private int[] dice;
	
	public Yatzy(int d1, int d2, int d3, int d4, int d5) {
        dice = IntStream.of(d1, d2, d3, d4, d5).toArray();
    }
	
    public static int chance(int d1, int d2, int d3, int d4, int d5) {
    	
    	return IntStream.of(d1, d2, d3, d4, d5).sum();
    }

    public static int yatzy(int... dice) {
    	
    	return IntStream.of(dice).boxed().allMatch(Integer.valueOf(dice[0])::equals) ? 50 : 0;
	}

    public static int ones(int d1, int d2, int d3, int d4, int d5) {

    	return IntStream.of(d1, d2, d3, d4, d5).filter(dice -> dice == 1).sum();
    }

    public static int twos(int d1, int d2, int d3, int d4, int d5) {
    	
    	return IntStream.of(d1, d2, d3, d4, d5).filter(dice -> dice == 2).sum();
    }

    public static int threes(int d1, int d2, int d3, int d4, int d5) {
    	
    	return IntStream.of(d1, d2, d3, d4, d5).filter(dice -> dice == 3).sum();
    }

    public int fours() {
    	
    	return IntStream.of(dice).filter(d -> d == 4).sum();
    }

    public int fives() {
    	
    	return IntStream.of(dice).filter(d -> d == 5).sum();
    }

    public int sixes() {
    	
    	return IntStream.of(dice).filter(d -> d == 6).sum();
    }

    public static int score_pair(int d1, int d2, int d3, int d4, int d5) {
    	
    	return buildScore(d1, d2, d3, d4, d5, 2);
    }

    public static int two_pair(int d1, int d2, int d3, int d4, int d5) {
        List<Integer> valuesList = buildValuesList(d1, d2, d3, d4, d5);
        
        AtomicInteger n = new AtomicInteger(0);
        AtomicInteger score = new AtomicInteger(0);
        IntStream.range(0, 6)
        	.filter(i -> valuesList.get(6-i-1) >= 2)
        	.forEach(item -> {
        		n.incrementAndGet();
        		score.addAndGet(item*2);
        	});
        
        if (n.get() == 2)
            return score.get() * 2;
        else
            return 0;
        
    }

    public static int four_of_a_kind(int d1, int d2, int d3, int d4, int d5) {
    	return buildScore(d1, d2, d3, d4, d5, 4);
    }

    public static int three_of_a_kind(int d1, int d2, int d3, int d4, int d5) {
    	return buildScore(d1, d2, d3, d4, d5, 3);
    }

    public static int smallStraight(int d1, int d2, int d3, int d4, int d5) {
    	List<Integer> valuesList = buildValuesList(d1, d2, d3, d4, d5);
    	return (IntStream.range(0, valuesList.size()).filter(i -> valuesList.get(i) == i).findFirst().isPresent()) ? 15 : 0;
    }

    public static int largeStraight(int d1, int d2, int d3, int d4, int d5)  {
    	List<Integer> valuesList = buildValuesList(d1, d2, d3, d4, d5);
    	return (IntStream.range(0, valuesList.size()).filter(i -> valuesList.get(i) == i).findFirst().isPresent()) ? 20 : 0;
    }

    public static int fullHouse(int d1, int d2, int d3, int d4, int d5) {
    	AtomicInteger sum = new AtomicInteger(0);
		Map<Integer, Long> result = Stream.of(d1, d2, d3, d4, d5)
		                                  .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

		if (result.values().size() != 2)
			return 0;
		else
			result.keySet().stream().forEach(key -> sum.set(sum.get() + key * result.get(key).intValue()));
		return sum.get();
    }
   
    private static List<Integer> buildValuesList(int d1, int d2, int d3, int d4, int d5) {
		int[] list = new int[6];
         List<Integer> parametersList = new ArrayList<>(Arrays.asList(d1, d2, d3, d4, d5));
         List<Integer> valuesList = Arrays.stream(list).boxed().collect(Collectors.toList());
         IntStream.range(0, valuesList.size()-1)
         	.forEach(i -> valuesList.set(parametersList.get(i) - 1, valuesList.get(parametersList.get(i) - 1) + 1)
         	);
		return valuesList;
	}
    
    private static int buildScore(int d1, int d2, int d3, int d4, int d5, int score) {
		int element = 0;
		int nbrElement = 0;
		List<Integer> dices = Arrays.asList(d1, d2, d3, d4, d5);
		Collections.sort(dices, Comparator.reverseOrder());
		
		for (int item : dices) {
			if (nbrElement == item) {
				element++;
				if (element == score) {
					break;
				}
			} else {
				element = 1;
				nbrElement = item;
			}
		}

		if (element == score)
			return element * nbrElement;

		return 0;
	}
}